#!/bin/sh
#: update the LWP book zip
#==========================================================================

set -e   # = abort this script on error
cd

BookDir="./lwpbook"
OutputZip="temp/lwpbook.zip"

test -e "$BookDir" || exit 57

zip  --update --recurse-paths "$OutputZip"   "$BookDir" -x '*~*'
