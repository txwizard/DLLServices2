﻿// this is the download file of the CodeProject article 'Understand how bitwise operators work (C# and VB.NET examples)' by ProgramFOX
// location of article: http://www.codeproject.com/Articles/544990/Understand-how-bitwise-operators-work-Csharp-and-V
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitwiseOperatorsCS
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }

        /// <summary>
        /// Calculates a | b
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="b">The second byte</param>
        /// <returns>a | b</returns>
        static byte InclusiveORoperator(byte a, byte b)
        {
            return (byte)(a | b);
        }

        /// <summary>
        /// Calculates a &amp; b
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="b">The second byte</param>
        /// <returns>a &amp; b</returns>
        static byte ANDoperator(byte a, byte b)
        {
            return (byte)(a & b);
        }

        /// <summary>
        /// Calculates a ^ b
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="b">The second byte</param>
        /// <returns>a ^ b</returns>
        static byte XORoperator(byte a, byte b)
        {
            return (byte)(a ^ b);
        }

        /// <summary>
        /// Calculates ~a, calculates the inverse of a
        /// </summary>
        /// <param name="a">The byte</param>
        /// <returns>~a, the inverse of a</returns>
        static byte NOToperator(byte a)
        {
            return (byte)~a;
        }

        /// <summary>
        /// Calculates a &lt;&lt; b
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="b">The second byte</param>
        /// <returns>a &lt;&lt; b</returns>
        static byte LeftShift(byte a, byte b)
        {
            return (byte)(a << b);
        }

        /// <summary>
        /// Calculates a &gt;&gt; b
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="b">The second byte</param>
        /// <returns>a &gt;&gt;</returns>
        static byte RightShift(byte a, byte b)
        {
            return (byte)(a >> b);
        }

        /// <summary>
        /// Calculates a circularleftshift n, which is equal to (a &lt;&lt; n | a &gt;&gt; (8 - n)) where a and n are two bytes
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="n">The second byte</param>
        /// <returns>a circularleftshift n</returns>
        static byte CircularLeftShift(byte a, byte n)
        {
            return (byte)(a << n | a >> (8 - n));
        }

        /// <summary>
        /// Calculates a circularrightshift n, which is equal to (a &gt;&gt; n | a &lt;&lt; (8 - n)) where a and n are two bytes
        /// </summary>
        /// <param name="a">The first byte</param>
        /// <param name="n">The second byte</param>
        /// <returns>a circularrightshift n</returns>
        static byte CircularRightShift(byte a, byte n)
        {
            return (byte)(a >> n | a << (8 - n));
        }

        /// <summary>
        /// Encrypts a string using XOR encryption with a string as key.
        /// </summary>
        /// <param name="str">The string to encrypt.</param>
        /// <param name="k">The key</param>
        /// <returns>The encrypted string</returns>
        static string XORencryptionWithStringAsKey(string str, string k)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.Length; i++)
            {
                sb.Append((char)(str[i] ^ k[i % k.Length]));
            }
            return sb.ToString();
        }

        /// <summary>
        /// Encrypts a string using XOR encryption with a char as key.
        /// </summary>
        /// <param name="str">The string to encrypt.</param>
        /// <param name="k">The key</param>
        /// <returns>The encrypted string</returns>
        static string XORencryptionWithCharAsKey(string str, char k)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                sb.Append((char)(c ^ k));
            }
            return sb.ToString();
        }

        /// <summary>
        /// Swaps two integers using the XOR swap algorithm.
        /// </summary>
        /// <param name="a">The first integer</param>
        /// <param name="b">The second integer</param>
        static void XORswap(ref int a, ref int b)
        {
            a = a ^ b;
            b = a ^ b;
            a = a ^ b;
        }

        /// <summary>
        /// Calculates pow(2, p)
        /// </summary>
        /// <param name="p">The exponent</param>
        /// <returns>1 &lt;&lt;, which is equal to  pow(2,p)</returns>
        static int PowersOfTwoUsingLeftShift(int p)
        {
            return 1 << p;
        }

        /// <summary>
        /// Calculates x / pow(2,n)
        /// </summary>
        /// <param name="x">The integer to divide with pow(2,n)</param>
        /// <param name="n">The exponent</param>
        /// <returns>x &gt;&gt; n, which is equal to x / pow(2,n)</returns>
        static int DivideByPowersOfTwoUsingRightShift(int x, int n)
        {
            return x >> n;
        }

        [Flags]
        public enum Priority
        {
            None = 0,
            VeryLow = 1,
            Low = 2,
            Medium = 4,
            High = 8,
            VeryHigh = 16
        }

        public enum PriorityWithoutFlagsAttr
        {
            None = 0,
            VeryLow = 1,
            Low = 2,
            Medium = 4,
            High = 8,
            VeryHigh = 16
        }

        /// <summary>
        /// An example with FlagsAttribute
        /// </summary>
        static void FlagsAttributeExample()
        {
            Priority p = Priority.Medium | Priority.High;
            Console.WriteLine(p.ToString()); // output: Medium, High
            PriorityWithoutFlagsAttr p2 = PriorityWithoutFlagsAttr.Medium | PriorityWithoutFlagsAttr.High;
            Console.WriteLine(p2.ToString()); // output: 12
        }

    }
}
