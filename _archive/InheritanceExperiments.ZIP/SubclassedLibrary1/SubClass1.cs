﻿using System;
using System.Reflection;

using BaseClassLibrary1;

namespace SubclassedLibrary1
{
	/// <summary>
	/// This class inherits a base class that is defined in another assembly.
	/// </summary>
    public class SubClass1 : BaseClass1
    {
		/// <summary>
		/// The one and only constructor calls the protected base constructor,
		/// then initializes two local members.
		/// </summary>
		public SubClass1 ( ) : base ( )
		{
			_strSubclassOwner = Assembly.GetCallingAssembly ( ).Location;
			_strSubclasImplemnter = Assembly.GetExecutingAssembly ( ).Location;
		}	// public SubClass1 constructor (1 of 1)


		private string _strSubclassOwner;
		private string _strSubclasImplemnter;


		/// <summary>
		/// Return the location of the assembly that implements this class.
		/// </summary>
		public string SubclasImplemnter
		{
			get
			{
				return _strSubclasImplemnter;
			}	// public string SubclassOwner Property Getter
		}	// public string SubclassOwner Read Only Property

	
		/// <summary>
		/// Return the location of the assembly that called this instance into being.
		/// </summary>
		public string SubclassOwner
		{
			get
			{
				return _strSubclassOwner;
			}	// public string SubclassOwner Property Getter
		}	// public string SubclassOwner Read Only Property
	}	//  public class SubClass1
}	// namespace SubclassedLibrary1