﻿using System;
using System.Reflection;

namespace BaseClassLibrary1
{
	/// <summary>
	/// First, this class is directly instantiated, then a derived class defined
	/// in a different assembly is instantiated by the same calling assembly.
	/// </summary>
    public class BaseClass1
    {
		const string UNINITIALIZED = @"Uninitialized";

		/// <summary>
		/// To differentiate it from the protected constructor, the public
		/// constructor takes a string containing the location of the calling
		/// assembly,
		/// </summary>
		/// <param name="pstrCallingAssemblyLocation">
		/// Pass in a string that represents the location of the calling
		/// assembly, as seen from its viewpoint.
		/// </param>
		public BaseClass1 ( string pstrCallingAssemblyLocation )
		{
			_strConstructorCallingAssembly = pstrCallingAssemblyLocation;
			_strDefiningAssembly = Assembly.GetExecutingAssembly ( ).Location;
		}	// BaseClass1 constructor (1 of 2)


		/// <summary>
		/// The protected constructor initializes the SubclassOwnerAssembly property.
		/// </summary>
		protected BaseClass1 ( )
		{
			_strBaseClassOwnerAssembly = Assembly.GetCallingAssembly ( ).Location;
			_strDefiningAssembly = Assembly.GetExecutingAssembly ( ).Location;
		}	// BaseClass1 constructor (2 of 2)

		private string _strBaseClassOwnerAssembly;
		private string _strConstructorCallingAssembly;
		private string _strDefiningAssembly;


		/// <summary>
		/// The default constructor initializes this read only property with the location of the calling assembly.
		/// </summary>
		public string BaseClassOwnerAssembly
		{
			get
			{
				return string.IsNullOrEmpty ( _strBaseClassOwnerAssembly ) ? UNINITIALIZED : _strBaseClassOwnerAssembly;
			}	// public string BaseClassOwnerAssembly Getter
		}	// public string BaseClassOwnerAssembly Read Only Property


		/// <summary>
		/// The public constructor initializes this property with the assembly location specified in the call.
		/// </summary>
		public string ConstructorCallingAssembly
		{
			get
			{
				return string.IsNullOrEmpty ( _strConstructorCallingAssembly ) ? UNINITIALIZED : _strConstructorCallingAssembly;
			}	// public string ConstructorCallingAssembly Property Getter
		}	// public string ConstructorCallingAssembly Read Only Property


		/// <summary>
		/// All constructors initialize this property with the location of the executing assembly.
		/// </summary>
		public string DefiningAssembly
		{
			get
			{
				return string.IsNullOrEmpty ( _strDefiningAssembly ) ? UNINITIALIZED : _strDefiningAssembly;
			}	// public string DefiningAssembly Getter
		}	// public string DefiningAssembly Read Only Property
	}	// public class BaseClass1
}	// namespace BaseClassLibrary1