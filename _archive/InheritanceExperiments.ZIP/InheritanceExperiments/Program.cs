﻿using System;
using System.Reflection;

using BaseClassLibrary1;
using SubclassedLibrary1;

namespace InheritanceExperiments
{
	class Program
	{
		static void Main ( string [ ] args )
		{
			Console.WriteLine ( "BOJ {0}{1}" , System.Reflection.Assembly.GetExecutingAssembly ( ).FullName , Environment.NewLine );
			
			BaseClass1 bc = new BaseClass1 ( Assembly.GetExecutingAssembly ( ).Location );
			
			Console.WriteLine ( "    BaseClass1: BaseClassOwnerAssembly Location     = {0}" , bc.BaseClassOwnerAssembly );
			Console.WriteLine ( "    BaseClass1: ConstructorCallingAssembly Location = {0}" , bc.ConstructorCallingAssembly );
			Console.WriteLine ( "    BaseClass1: DefiningAssembly Location           = {0}{1}" , bc.DefiningAssembly , Environment.NewLine );

			SubClass1 sc = new SubClass1 ( );

			Console.WriteLine ( "    SubClass1: BaseClassOwnerAssembly Location     = {0}" , sc.BaseClassOwnerAssembly );
			Console.WriteLine ( "    SubClass1: DefiningAssembly Location           = {0}" , sc.DefiningAssembly );
			Console.WriteLine ( "    SubClass1: SubclasImplemnter Location          = {0}" , sc.SubclasImplemnter );
			Console.WriteLine ( "    SubClass1: SubclassOwner Location              = {0}{1}" , sc.SubclassOwner , Environment.NewLine );
			
			Console.WriteLine ( "{1}EOJ {0}" , System.Reflection.Assembly.GetExecutingAssembly ( ).FullName , Environment.NewLine );

			Environment.Exit ( 0 );
		}	// static void Main
	}	// class Program
}	// namespace InheritanceExperiments